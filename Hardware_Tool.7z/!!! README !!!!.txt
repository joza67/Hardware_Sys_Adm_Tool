Ovaj cijeli folder se mora nalaziti na lokaciji root C i zvati se folder kako se zove sada inače neće raditi search opcija, znači mora biti:
C:\NEMAM INSTALACIJU I JAKO SAM GLUP PA ME KOPIRAJ U C_root

Jer kad napravim skriptu za instalaciju ne instaliraju se neki readeri za excel tablice i ne da mi se zajebavat uopće s time. 

Samo copy/pasty ili unpack u C:/root

Onda kopiraš ovu POKRENI ME.exe aplikaciju i na DESKTOP zalijepi as shortcut 
i onda mu daš ime po želji.

I onda će će u prozoru konzole program zvati kako si dao ime shortcutu na DESKTOP-u :)
Npr: "Hardware_Little_Helper" :)


Kada ga pokreneš, prvo će te pitati da izabereš boju teksta, pa moraš izabrati i upisati jedan broj 1-4 i stisnuti enter.
Bijela mi smeta, crvena te čini nervoznim, dakle zelena ili plava nisu loše.


Program nudi 4 opcije, i onda moraš izabrati i upisati jedan broj 1-4 i stisnuti enter.

1.
Pretragu trgovina po imenu, mjestu i ključnoj riječi.
npr. Upišeš vetovo, ili gornji miholjac ili revita 39 ili sara ili vlatka ili broj trgovine s time da je baza podataka 2 excel tablice, 
pa ako po imenu trgovine ne pokaže odmah rezultate iz obje tablice, to je zato što se iz jedne tablice ne poklapaju 2 ili više ćelija sa
drugom tablicom, pa onda kad ti pokaže rezultate, kopiraš točno ime, mjesto ili ključnu riječ kako piše, odabereš opciju 1 opet, pa će
izbaciti rezultate iz obje tablice :) Iz druge pali sigurno hahaha.

2.
Pinga zadanu IP adresu. Pinga kao kada napišeš ping -t xxx.xxxx.xxx.xxx u Win CMD, i prestaje tek kada pritisneš SPACE. 
Jako zgodno ako prekida neki kabel, pa kad na drugoj strani netko mrda po kablovima možeš vidjeti da li utječe na adresu koju
pingaš, npr. meni je pomoglo par puta :)

3.
Skenira mrežu u rasponu od/do i prikazuje uređaje koje je pingao na toj mreži. npr. 192.168.100.1 - 192.168.100.254
Funkcionira kao opcija 2 :), kad pingaš u Win CMD s time da automatski pokuša pingati 6 puta svaku adresu sa timeoutom od 1 sekunde,
pa je malo sporiji :), ali zato jako točan.

4.
Izlaz iz programa, ali ga možeš uvijek zatvoriti na X :)


Možeš copy/pasteat linije teksta, ali sa Ctrl+C i Ctrl+V jer u konzolnoj aplikaciji desni klik miša nema svrhu :).
Back to the 1980's :) ako misliš da je Total CMD bio divna stvar, ovo ti je onda najbolji User Interface na svijetu.

Program je napravljen 11/2023 i kod je napisan u Visual Studio 2022 koji je besplatan za korisnike MS windowsa. Jezik je C#. 
Treba .NET Framework version 4.8 jer sam ja glup što sam to stavio kad sam počeo pisati projekt, neda mi se iznova, vjv neće
raditi na Windowsu 7...Kod je cijeli uključen ovdje u Folderu pa radi s kodom što te volja. Planiram nekad još napraviti 
jednostavno grafičko sučelje za korisnika, ali o tom potom.... 

