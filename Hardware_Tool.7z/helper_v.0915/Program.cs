﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ExcelDataReader;
using Diacritics.Extensions;
using System.Linq;

class Program
{
    static async Task Main()
    {
        string[] excelFiles =
        {
            @"C:\NEMAM INSTALACIJU I JAKO SAM GLUP PA ME KOPIRAJ U C_root\DATABASE NTL\NTL, popis MPLS lokacija istok.xlsx",
            @"C:\NEMAM INSTALACIJU I JAKO SAM GLUP PA ME KOPIRAJ U C_root\DATABASE NTL\IMENIK NTL.xls"
        };

        SetConsoleColors();

        while (true)
        {
            Console.WriteLine();
            Console.WriteLine(" !!! Made by J.T. with a help of the ChatGPT on 11/2023. !!! ");
            Console.WriteLine(" !!! Please feel free to use & abuse 4 ever & 4 free !!! ");
            Console.WriteLine();
            Console.WriteLine(" !!! THIS IS MY MAIN MENU !!! :");
            Console.WriteLine();
            Console.WriteLine(" Press a number to select an option: ");
            Console.WriteLine();
            Console.WriteLine(" 1. Search ");
            Console.WriteLine(" Pretrazi ducane, po imenu, mjestu, ili kljucnoj rijeci ");
            Console.WriteLine();
            Console.WriteLine(" 2. Ping ");
            Console.WriteLine(" Pingaj zadanu IP adresu u formatu xxx.xxx.xxx.xxx !!! SPACE TO STOP PING !!! ");
            Console.WriteLine();
            Console.WriteLine(" 3. Scan ");
            Console.WriteLine(" Skenira/Pinga sve Uređaje/IP adrese na zadanoj mreži od/do u formatu xxx.xxx.xxx.xxx ");
            Console.WriteLine();
            Console.WriteLine(" 4. Exit ");
            Console.WriteLine();
            Console.WriteLine(" ! Now U must choose one number 1-4 ! ");
            Console.WriteLine();

            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    SearchKeyword(excelFiles);
                    break;
                case "2":
                    await PingIPAsync();
                    break;
                case "3":
                    await ScanIPRangeAsync();
                    break;
                case "4":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }

    static void SetConsoleColors()
    {
        Console.ResetColor(); // Reset colors to default
        Console.WriteLine();
        Console.WriteLine(" Made by J.T. 11/23 !!! Please feel free to use & modify as you please forever & for free!!! ");
        Console.WriteLine();
        Console.WriteLine(" Choose a text color: ");
        Console.WriteLine();

        DisplayColoredText(" 0. Gray ", ConsoleColor.Gray);
        DisplayColoredText(" 1. Red ", ConsoleColor.Red);
        DisplayColoredText(" 2. Orange ", ConsoleColor.DarkYellow);
        DisplayColoredText(" 3. Magenta ", ConsoleColor.Magenta);
        DisplayColoredText(" 4. Yellow ", ConsoleColor.Yellow);
        DisplayColoredText(" 5. Cyan ", ConsoleColor.Cyan);
        DisplayColoredText(" 6. Green ", ConsoleColor.Green);
        DisplayColoredText(" 7. Blue ", ConsoleColor.Blue);
        DisplayColoredText(" 8. Dark Blue ", ConsoleColor.DarkBlue);
        DisplayColoredText(" 9. White ", ConsoleColor.White);

        Console.WriteLine();
        Console.WriteLine(" Now you must choose a number 0-9 for text color ");
        Console.WriteLine();

        string textColorOption = Console.ReadLine();

        SetTextColor(textColorOption);
    }

    static void DisplayColoredText(string text, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(text);
        Console.ResetColor();
    }

    static void SetTextColor(string option)
    {
        if (int.TryParse(option, out int colorCode) && colorCode >= 0 && colorCode <= 9)
        {
            // Map color codes to actual colors in the console
            ConsoleColor[] colorMap = {
            ConsoleColor.Gray, // 0. Gray
            ConsoleColor.Red,     // 1. Red
            ConsoleColor.DarkYellow, // 2. Orange
            ConsoleColor.Magenta,  // 3. Magenta
            ConsoleColor.Yellow,  // 4. Yellow
            ConsoleColor.Cyan,    // 5. Cyan
            ConsoleColor.Green,   // 6. Green
            ConsoleColor.Blue,    // 7. Blue
            ConsoleColor.DarkBlue,// 8. Dark Blue
            ConsoleColor.White    // 9. White
        };

            Console.ForegroundColor = colorMap[colorCode];
        }
        else
        {
            Console.WriteLine("Invalid text color option. Using the default color (White).");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White; // Set default color explicitly
        }
    }

    static async Task ScanIPRangeAsync()
    {
        Console.WriteLine();
        Console.WriteLine("Enter the start IP address (e.g., xxx.xxx.xxx.xxx):");
        Console.WriteLine();
        string startIp = Console.ReadLine();

        Console.WriteLine();
        Console.WriteLine("Enter the end IP address (e.g., xxx.xxx.xxx.xxx):");
        Console.WriteLine();
        string endIp = Console.ReadLine();

        Console.WriteLine("Scanning IP addresses...");

        if (IsValidIpAddress(startIp) && IsValidIpAddress(endIp))
        {
            IPAddress startIPAddress = IPAddress.Parse(startIp);
            IPAddress endIPAddress = IPAddress.Parse(endIp);

            byte[] startBytes = startIPAddress.GetAddressBytes();
            byte[] endBytes = endIPAddress.GetAddressBytes();

            List<Task<string>> pingTasks = new List<Task<string>>();

            for (long a = startBytes[0]; a <= endBytes[0]; a++)
            {
                for (long b = startBytes[1]; b <= endBytes[1]; b++)
                {
                    for (long c = startBytes[2]; c <= endBytes[2]; c++)
                    {
                        for (long d = startBytes[3]; d <= endBytes[3]; d++)
                        {
                            byte byteA = (byte)a;
                            byte byteB = (byte)b;
                            byte byteC = (byte)c;
                            byte byteD = (byte)d;

                            IPAddress currentIp = new IPAddress(new byte[] { byteA, byteB, byteC, byteD });
                            string ipAddress = currentIp.ToString();

                            pingTasks.Add(PingIPAsync(ipAddress));
                        }
                    }
                }
            }

            await Task.WhenAll(pingTasks);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(" ! SCANNING OF THE NETWORK COMPLETE ! ");
            Console.WriteLine();
            Console.WriteLine(" Results are based on 8 times trying to ping address (8x retry). ");
            Console.WriteLine(" Timeout set at=1000ms ");
            Console.WriteLine(" ! I got reply from these IP addresses: ! ");

            List<string> activeDevices = new List<string>();

            foreach (var task in pingTasks)
            {
                if (!string.IsNullOrEmpty(task.Result))
                {
                    activeDevices.Add(task.Result);
                }
            }

            if (activeDevices.Count > 0)
            {
                Console.WriteLine("Active devices:");
                foreach (var device in activeDevices)
                {
                    Console.WriteLine(device);
                }
            }
            else
            {
                Console.WriteLine("No active devices found.");
            }
        }
        else
        {
            Console.WriteLine("Invalid IP address format. Please enter valid IP addresses.");
        }
    }

    static async Task<string> PingIPAsync(string ipAddress)
    {
        int maxRetries = 8;
        int timeout = 1000;

        using (Ping ping = new Ping())
        {
            Console.WriteLine($"Pinging {ipAddress} with {maxRetries} times, timeout={timeout}ms:");

            for (int retry = 0; retry < maxRetries; retry++)
            {
                PingReply reply = await ping.SendPingAsync(ipAddress, timeout);

                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine($"Reply from {ipAddress}: bytes=32 time={reply.RoundtripTime}ms TTL={reply.Options.Ttl}");
                    return ipAddress;
                }
                else
                {
                    Console.WriteLine($"Ping to {ipAddress} failed. Error: {reply.Status}");
                    if (retry < maxRetries - 1)
                        Console.WriteLine("Retrying...");
                }
            }
            return null;
        }
    }

    static async Task PingIPAsync()
    {
        string ipAddress = GetValidIpAddress();

        Console.WriteLine($"Pinging {ipAddress} with 32 bytes of data:");
        //var ping = new Ping();

        while (!Console.KeyAvailable || Console.ReadKey(true).Key != ConsoleKey.Spacebar)
        {
            await PingIPAsync(ipAddress);
        }
    }


    static void SearchKeyword(string[] excelFiles)
    {
        Console.WriteLine(" UPISI - Mjesto, Ime ili Broj trgovine ili Keyword (ILI napiši 'exit' i udari ENTER :) ");
        string keyword = Console.ReadLine();

        if (string.Equals(keyword, "exit", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        keyword = keyword.RemoveDiacritics();

        List<string[]> resultsFile1 = new List<string[]>();
        List<string[]> resultsFile2 = new List<string[]>();

        SearchAndCollectResults(excelFiles[0], keyword, resultsFile1);
        SearchAndCollectResults(excelFiles[1], keyword, resultsFile2);

        bool foundInFile1 = resultsFile1.Count > 0;
        bool foundInFile2 = resultsFile2.Count > 0;

        if (!foundInFile1 && !foundInFile2)
        {
            Console.WriteLine($"Keyword '{keyword}' not found in any file.");
        }
        else
        {
            if (foundInFile1)
            {
               // to ti ne treba tu da piše target di je našao !! Console.WriteLine($"Results from {excelFiles[0]}:");
                DisplayResults(excelFiles[0], resultsFile1);
            }

            if (foundInFile2)
            {
                // to ti ne treba tu da piše target di je našao !! Console.WriteLine($"Results from {excelFiles[1]}:");
                DisplayResults(excelFiles[1], resultsFile2);
            }

            if (foundInFile1 && foundInFile2)
            {
                CompareResults(excelFiles, resultsFile1, resultsFile2);
            }
        }
    }

    static void SearchAndCollectResults(string excelFilePath, string keyword, List<string[]> results)
    {
        using (var stream = File.Open(excelFilePath, FileMode.Open, FileAccess.Read))
        {
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                reader.Read(); // Move to the first row (headers)
                reader.Read(); // Move to the second row (column names)

                while (reader.Read())
                {
                    bool foundInRow = false;
                    List<string> rowData = new List<string>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        var cellValue = reader[i];
                        if (cellValue != null)
                        {
                            var cellValueString = cellValue.ToString();
                            cellValueString = cellValueString.RemoveDiacritics();

                            if (cellValueString.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                foundInRow = true;
                            }
                            rowData.Add(cellValueString);
                        }
                        else
                        {
                            rowData.Add(""); // If cell is null, add an empty string
                        }
                    }

                    if (foundInRow)
                    {
                        results.Add(rowData.ToArray());
                    }
                }
            }
        }
    }

    static void DisplayResults(string excelFilePath, List<string[]> results)
    {
        // ne treba ti tu !! string fileName = Path.GetFileName(excelFilePath); // Extracting the file name

        using (var stream = File.Open(excelFilePath, FileMode.Open, FileAccess.Read))
        {
            using (var reader = ExcelReaderFactory.CreateReader(stream))
            {
                reader.Read(); // Move to the first row (headers)
                reader.Read(); // Move to the second row (column names)

                var columnNames = new List<string>();

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var columnName = reader[i]?.ToString();
                    columnNames.Add(columnName);
                }

                foreach (var row in results)
                {
                    for (int i = 0; i < row.Length; i++)
                    {
                        
                        Console.WriteLine($"{columnNames[i]}: {row[i]}");
                        
                    }
                    
                    Console.WriteLine("-------------");
                    
                }
            }
        }
    }


    static void CompareResults(string[] excelFiles, List<string[]> resultsFile1, List<string[]> resultsFile2)
    {
        Console.WriteLine();
        Console.WriteLine("! Rezultati iz obje tablice - traži po fiksnom broju, imenu ili mjestu ako ne nađe rezultate iz obje ! ");
        Console.WriteLine();

        foreach (var resultFile1 in resultsFile1)
        {
            foreach (var resultFile2 in resultsFile2)
            {
                if (resultFile1.SequenceEqual(resultFile2))
                {
                    DisplayResults(excelFiles[0], new List<string[]> { resultFile1 });
                   
                    Console.WriteLine("------------");
                    
                    break;
                }
            }
        }
    }

    static string GetValidIpAddress()
    {
        string ipAddress = string.Empty;
        bool isValidIp = false;

        while (!isValidIp)
        {
            Console.WriteLine("!!! USE SPACE BAR TO STOP PINGING !!!");
            Console.WriteLine();
            Console.Write("Enter the IP address to ping: ");
            Console.WriteLine();
            ipAddress = Console.ReadLine();

            isValidIp = IsValidIpAddress(ipAddress);
        }

        return ipAddress;
    }

    static bool IsValidIpAddress(string ipAddress)
    {
        string pattern = @"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$";

        if (!Regex.IsMatch(ipAddress, pattern))
        {
            Console.WriteLine("Invalid IP address format. Please enter a valid IP address.");
            return false;
        }

        if (IPAddress.TryParse(ipAddress, out _))
        {
            return true;
        }
        else
        {
            Console.WriteLine("Invalid IP address. Please enter a valid IP address.");
            return false;
        }
    }
}